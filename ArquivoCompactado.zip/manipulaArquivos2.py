import os
import shutil
from os import path
from shutil import make_archive
from zipfile import ZipExtFile

def CriaZipModo1():
    shutil.make_archive("ArquivoCompactado", "zip", "C:\\Users\\Amorim\\OneDrive\\Python\\PythonLinkedinLearning\\Cap3 - TrabalhandoComArquivos" )

CriaZipModo1()
